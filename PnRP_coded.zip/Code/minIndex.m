function I = minIndex(HC)
tmp = inf;
for k = 1:size(HC,2)
    if(HC(k).PE<tmp)
        tmp=HC(k).PE;
        I = k;
    end
end
end