function [code1] = nullpad(code,f,n)
%This function pads the array of codes such that the code for a character
%is at the index equal to the ascii value of the character
code1=strings(1,2^n);
    for k=1:size(f,2)
        code1(f(k))=code(k);
    end
    
end

