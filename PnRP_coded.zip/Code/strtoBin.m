function b = strtoBin(s)
b=zeros(1,size(s,2));
for k=1:size(s,2)
      
    b(k)=str2num(s(k));
       
end

end

